import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProjectCard from "@/components/ProjectCard";

export default function Bots() {
  return (
    <div className="min-h-screen w-full bg-[#0A0F1E] text-white flex flex-col">
      <Navbar />
      <main className="mx-auto max-w-6xl w-full px-6 py-14">
        <h2 className="text-3xl font-bold mb-6">Bots</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ProjectCard title="Scalper Bot" description="Fast-execution bot optimized for low-latency scalps." />
          <ProjectCard title="Swing Bot" description="AI-assisted trade bot designed for longer holds." />
        </div>
      </main>
      <Footer />
    </div>
  );
}
