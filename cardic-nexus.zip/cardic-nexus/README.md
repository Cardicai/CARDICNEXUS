# Cardic Nexus

Hub for advanced trading intelligence:
- **Indicators**: CN Pro RSI, Cardic Heat 2.0 & 2.1
- **Expert Advisors (EA)**: Automated strategies for MT5
- **Bots**: AI-powered assistants

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel
1. Push this project to GitHub.
2. Go to vercel.com → New Project → Import your repo → Deploy.

## Contact
- WhatsApp: https://wa.me/447365718250
- Telegram: https://t.me/REALCARDIC
- X/Twitter: https://x.com/CARDICNEXUS?t=BRY7dNyOwxNLdRjcZNBt0w&s=09
