export default function ProjectCard({ title, description }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-[linear-gradient(180deg,rgba(30,64,175,0.15),rgba(3,7,18,0.3))] p-6 hover:border-blue-500/30 transition">
      <h3 className="text-xl font-semibold text-cyan-300">{title}</h3>
      <p className="text-white/70 text-sm mt-2">{description}</p>
    </div>
  );
}
