/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        cardicBlue: "#0a0f1f",
        cardicDark: "#0b1226",
        cardicAccent: "#1542D8",
        cardicCyan: "#0EA5E9"
      }
    }
  },
  plugins: []
};
