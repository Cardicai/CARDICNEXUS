import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="bg-[#0B1428]/50 backdrop-blur border-b border-white/10 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="h-8 w-8 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 grid place-items-center shadow-lg shadow-blue-500/30" />
        <span className="font-semibold tracking-wide">Cardic Nexus</span>
      </div>
      <div className="hidden md:flex items-center gap-6 text-sm text-white/80">
        <Link href="/">Home</Link>
        <Link href="/indicators">Indicators</Link>
        <Link href="/ea">EA</Link>
        <Link href="/bots">Bots</Link>
      </div>
    </nav>
  );
}
