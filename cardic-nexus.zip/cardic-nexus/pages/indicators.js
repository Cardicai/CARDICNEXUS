import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProjectCard from "@/components/ProjectCard";

export default function Indicators() {
  return (
    <div className="min-h-screen w-full bg-[#0A0F1E] text-white flex flex-col">
      <Navbar />
      <main className="mx-auto max-w-6xl w-full px-6 py-14">
        <h2 className="text-3xl font-bold mb-6">Indicators</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ProjectCard title="CN Pro RSI" description="Advanced RSI indicator for precision trading." />
          <ProjectCard title="Cardic Heat 2.0" description="Heatmap visualization for liquidity zones." />
          <ProjectCard title="Cardic Heat 2.1" description="Updated version with refined trigger signals and overlays." />
        </div>
      </main>
      <Footer />
    </div>
  );
}
