import { FaTelegramPlane, FaTwitter, FaWhatsapp } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="border-t border-white/10 mt-16 py-6 flex flex-col items-center space-y-4">
      <p className="text-white/60 text-sm">© Cardic Nexus 2025</p>
      <div className="flex space-x-6 text-2xl">
        <a
          href="https://t.me/REALCARDIC"
          target="_blank"
          rel="noreferrer"
          className="text-cyan-300 hover:text-cyan-200 transition-transform hover:scale-110"
        >
          <FaTelegramPlane />
        </a>
        <a
          href="https://x.com/CARDICNEXUS?t=BRY7dNyOwxNLdRjcZNBt0w&s=09"
          target="_blank"
          rel="noreferrer"
          className="text-sky-400 hover:text-sky-300 transition-transform hover:scale-110"
        >
          <FaTwitter />
        </a>
        <a
          href="https://wa.me/447365718250"
          target="_blank"
          rel="noreferrer"
          className="text-green-400 hover:text-green-300 transition-transform hover:scale-110"
        >
          <FaWhatsapp />
        </a>
      </div>
    </footer>
  );
}
