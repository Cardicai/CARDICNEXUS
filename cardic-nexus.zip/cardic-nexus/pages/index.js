import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProjectCard from "@/components/ProjectCard";

export default function Home() {
  return (
    <div className="min-h-screen w-full bg-[#0A0F1E] text-white flex flex-col">
      <Navbar />
      <main className="mx-auto max-w-6xl w-full px-6 py-14">
        <header className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold leading-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-cyan-300">Cardic Nexus</h1>
          <p className="mt-4 text-white/70 max-w-2xl mx-auto">
            Hub for Indicators, Expert Advisors, Bots, and advanced trading intelligence.
          </p>
        </header>
        <section>
          <h2 className="text-2xl font-semibold mb-6">Featured Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <ProjectCard title="Indicators" description="CN Pro RSI, Cardic Heat 2.0, Cardic Heat 2.1" />
            <ProjectCard title="Expert Advisors" description="Automated strategies for MT5" />
            <ProjectCard title="Bots" description="AI-powered trading & automation" />
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
