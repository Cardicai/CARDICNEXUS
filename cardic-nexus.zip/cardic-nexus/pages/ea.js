import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProjectCard from "@/components/ProjectCard";

export default function EA() {
  return (
    <div className="min-h-screen w-full bg-[#0A0F1E] text-white flex flex-col">
      <Navbar />
      <main className="mx-auto max-w-6xl w-full px-6 py-14">
        <h2 className="text-3xl font-bold mb-6">Expert Advisors</h2>
        <ProjectCard title="Nexus Alpha EA" description="ATR engine, partial TP, risk tiers, and hands-off execution." />
      </main>
      <Footer />
    </div>
  );
}
